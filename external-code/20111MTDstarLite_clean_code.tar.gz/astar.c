#include "heap.h"
#include "maze.h"
#include "astar.h"
#include "math.h"
#include "stdio.h"
#include "include.h"

#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>



#ifdef TESTASTAR

int x, y, d, d1, i;
int random_number;
double duration0 = 0;
double choose0 = 0;
double change0 = 0;
double newrandomaze0 = 0;
double choose_target_togo0 = 0; 
double change_grid_time = 0; 

struct timeval tv01, tv02, tv01choose, tv02choose, tv01change, tv02change;


#ifdef ADAPTIVE
#define MAZEITERATIONS 100000000
int targetdiscount[MAZEITERATIONS];
#define MAXSEARCHES 100000000
int pathlengths[MAXSEARCHES];   
#endif




int random_number1 = 0;
int flag_target_moved1 = 0;
int keymodifier1 = 0;
int times_of_billion1 = 0;
unsigned long int j;
unsigned long int mazeiteration1 = 0;
unsigned long int bfs_mazeiteration = 0;
unsigned long int searches_astar = 0;
unsigned long int statexpanded1 = 0;
unsigned long int statexpanded1_initial_thiscase;
unsigned long int statexpanded_percase = 0;
unsigned long int robot_steps0 = 0;
unsigned long int target_steps = 0;
unsigned long int robotmoves_total1 = 0;
unsigned long int counter_updates1 = 0;

float expansion_per_search = 0;
float expansion_persearch1[ALLMAXSEARCHES];
float average_expansion_persearch = 0;
float variance_expansion_persearch = 0;
float SDOM = 0;
cell *tmpcell1;
cell *tmpcell2;

void initialize_state(cell *tmpcell)
{
#ifndef REVERSE  // forward
#ifdef ADAPTIVE
    if(tmpcell->iteration == 0)
    {
        tmpcell->g = LARGE;
        tmpcell->h = HA(tmpcell, mazegoal);         
    }
    else if(tmpcell->iteration != mazeiteration1)
    {
        if(tmpcell->g + tmpcell->h < pathlengths[tmpcell->iteration])
            tmpcell->h = pathlengths[tmpcell->iteration] - tmpcell->g;
#ifdef RANDOMLYMOVE
        tmpcell->h = max ( (tmpcell->h + targetdiscount[tmpcell->iteration] - keymodifier1) ,   HA(tmpcell, mazegoal));
#endif  
        tmpcell->g = LARGE;
    }
#else
    if(tmpcell->iteration != mazeiteration1)
    {   
        tmpcell->g = LARGE;
        tmpcell->h = HA(tmpcell, mazegoal);
    }   
#endif
#else // reverse
#ifdef ADAPTIVE
    if(tmpcell->iteration == 0)
    {
        tmpcell->g = LARGE;
        tmpcell->h = HA(tmpcell, mazestart);            
    }
    else if(tmpcell->iteration != mazeiteration1)
    {
        if(tmpcell->g + tmpcell->h < pathlengths[tmpcell->iteration])
            tmpcell->h = pathlengths[tmpcell->iteration] - tmpcell->g;
        tmpcell->h = max ( (tmpcell->h + targetdiscount[tmpcell->iteration] - keymodifier1) ,   HA(tmpcell, mazestart) );
        tmpcell->g = LARGE; 
    }
#else
    if(tmpcell->iteration != mazeiteration1)
        tmpcell->g = LARGE;
    tmpcell->h = HA(tmpcell, mazestart);    
#endif
#endif  
    tmpcell->iteration = mazeiteration1;
    return;
}

/*------------------------------------------------------------------------*/
void initialize_astar()
{ 
    mazeiteration1 = 0;
    robot_steps0 = 0;
    flag_target_moved1 = 0;
    flag_changed = 0;
    bfs_mazeiteration = 0;
    mazegoal->bfs_trace = NULL;
    keymodifier1 = 0;
#ifdef ADAPTIVE
    pathlengths[0] = 0;
#endif
    statexpanded1_initial_thiscase = 0;
    return;
}

/*--------------------------------------------------------------------------------------------------*/
int computeshortestpath_astar()
{
    int flag_success = 0;
    
    flag_changed = 0; // the map is reset to be un-changed after compute path again
#ifdef STATISTICS   
    searches_astar++;
    statexpanded1_initial_thiscase = 0;
#endif
    
    mazeiteration1++;   
    
#ifdef ADAPTIVE
    targetdiscount[mazeiteration1] = keymodifier1;   // mazeiteration1 == 0 initially
#endif
    emptyheap2();
    
#ifndef REVERSE
    mazestart->g = 0;
    mazestart->h = HA(mazestart, mazegoal); 
    mazestart->key1 = (mazestart->g + mazestart->h) * BASE - mazestart->g;  
    mazestart->iteration = mazeiteration1;
    mazestart->searchtree = NULL;
    insertheap2(mazestart);   
#else  // reverse search
    mazegoal->g = 0;
    mazegoal->h = HA(mazegoal, mazestart);
    mazegoal->key1 = (mazegoal->g + mazegoal->h) * BASE - mazegoal->g;  
    mazegoal->iteration = mazeiteration1; 
    mazegoal->searchtree = NULL;
    insertheap2(mazegoal); 
#endif
    
    flag_success = 0;
    while (topheap2() != NULL)    /* 3 */
    {       
        tmpcell1 = popheap2();
        tmpcell1->expanded = mazeiteration1;
        
#ifdef STATISTICS   
        ++statexpanded1_initial_thiscase;
        ++statexpanded1; 
        if(statexpanded1 == 1000000000)
        {
            statexpanded1 = 0;
            times_of_billion1++;
        }
#endif  
#ifndef REVERSE
        if (tmpcell1 == mazegoal)
#else
            if (tmpcell1 == mazestart)         
#endif      
            {   
                flag_success = 1;
                break;
            }       
            for (d = 0; d < DIRECTIONS; ++d)
            {         
                if (tmpcell1->move[d] && tmpcell1->move[d]->expanded != mazeiteration1)
                {
                    initialize_state(tmpcell1->move[d]);
                    if(tmpcell1->move[d]->g > tmpcell1->g + 1)
                    {
                        tmpcell1->move[d]->g = tmpcell1->g + 1;
                        tmpcell1->move[d]->searchtree = tmpcell1;           
                        tmpcell1->move[d]->key1 = (tmpcell1->move[d]->g + tmpcell1->move[d]->h) * BASE - tmpcell1->move[d]->g;  
                        insertheap2(tmpcell1->move[d]);     
                    }           
                }
            }
    } /* end while */ 
    
    
#ifdef TESTDIFFERENTIALASTAR   // undo the search three for Differential A*
    if (flag_success == 1)
    {
        tmpcell1 = mazestart;
        undo_end = mazestart;
        undo_end->undo_next = NULL;
        
        while (1)
        {
            for (d = 0; d < DIRECTIONS; ++d)
            {         
                if (tmpcell1->move[d] && tmpcell1->move[d]->searchtree == tmpcell1 && tmpcell1->move[d]->iteration == mazeiteration1 )  
                {
                    if(tmpcell1->move[d]->heapindex == 0)   // 1. expanded cell 
                    {           
                        tmpcell1->move[d]->g = LARGE;  // undo the searchtree by set the g-value to be LARGE                
                        undo_end->undo_next = tmpcell1->move[d];
                        undo_end = tmpcell1->move[d];
                        undo_end->undo_next = NULL;
                    }
                    // if 2. this is an OPEN cell
                    else  //  if(tmpcell1->move[d]->heapindex > 0) // 2. generated open cell 
                    {
                        tmpcell1->move[d]->g = LARGE;
                        deleteheap2(tmpcell1->move[d]);
                    }
                }
            }// end for (d)
            
            if (tmpcell1->undo_next != NULL)
            {
                tmpcell1 = tmpcell1->undo_next;
            }
            else
                break;  // break while
        } // end while(1)
    }
#endif // end #ifdef TESTDIFFERENTIALASTAR
    
    if (flag_success == 1)
    {   
#ifdef ADAPTIVE 
#ifndef REVERSE
        pathlengths[mazeiteration1] = mazegoal->g;   // (g == f) for the mazegoal;
#else
        pathlengths[mazeiteration1] = mazestart->g;   // (g == f) for the mazestart;
#endif
#endif   
        
        if(mazeiteration1 == 1)  // if this is the first path
        {
            mazestart->in_path = 1;
            mazegoal->in_path = 1;
        }
#ifndef REVERSE    //  forward___
        mazegoal->trace = NULL;   // tracing back a path from the goal back to the start
        tmpcell2 = mazegoal;
        tmpcell2->path_iteration = mazeiteration1;
        
        if(mazeiteration1 == 1)  // if this is the first path
        {
            while(tmpcell2 != mazestart)
            {
                tmpcell2->searchtree->trace = tmpcell2;
                tmpcell2 = tmpcell2->searchtree;
                tmpcell2->path_iteration = mazeiteration1;  
                tmpcell2->in_path = 1;      
            }
        }   
        else
        {
            while(tmpcell2 != mazestart)
            {
                tmpcell2->searchtree->trace = tmpcell2;
                tmpcell2 = tmpcell2->searchtree;
                tmpcell2->path_iteration = mazeiteration1;  
            }       
        }
#else // search reverse
        tmpcell2 = mazestart;
        tmpcell2->path_iteration = mazeiteration1;
        if(mazeiteration1 == 1)  // if this is the first path
        {
            while(tmpcell2 != mazegoal)
            {
                tmpcell2 = tmpcell2->searchtree;
                tmpcell2->path_iteration = mazeiteration1;
                tmpcell2->in_path = 1;
            }
        }   
        else
        {
            while(tmpcell2 != mazegoal)
            {
                tmpcell2 = tmpcell2->searchtree;
                tmpcell2->path_iteration = mazeiteration1;
            }
        }      
#endif      
    }  // end if (flag_success == 1)
    
#ifdef STATISTICS
    expansion_persearch1[searches_astar] =  statexpanded1_initial_thiscase;
#endif
    return(flag_success);
}
/* ------------------------------------------------------------------------------*/




//--------------------------
void target_move()
{
    int bfs_expanded_number;
    short flag_target_can_move;
    
    target_steps++;
    flag_target_moved1 = 1;
    bfs_expanded_number = 0;
    bfs_mazeiteration++;
    
#ifdef UNKNOWN
    flag_target_can_move = 0;
    for (d = 0; d < DIRECTIONS; ++d)
    {         
        if (mazegoal->move[d] && mazegoal->move[d]->obstacle == 0)
        {
            flag_target_can_move = 1;
            break;              
        }
    }
    if(flag_target_can_move == 0)
    {
        flag_target_moved1 = 0;
        return; 
    }
#endif
    
    if(mazegoal->bfs_trace &&  mazegoal->bfs_trace->obstacle == 0)
    {
        mazegoal = mazegoal->bfs_trace;
    }
    else // we need to run BFS to identify a path for the target to go
    {
        mazegoal->bfs_g = 0;
        mazegoal->bfs_iteration = bfs_mazeiteration;
        mazegoal->bfs_searchtree = NULL;
        
        generate_anchor = mazegoal;
        generate_end = mazegoal;
        
        while (generate_anchor != NULL)
        {
            tmpcell1 = generate_anchor;  //prepare to expand
            bfs_expanded_number++;
            
            if(bfs_expanded_number == BFS_NUMBER)
                break;
            
            for (d = 0; d < DIRECTIONS; ++d)
            {         
#ifdef UNKNOWN
                if (tmpcell1->move[d] && tmpcell1->move[d]->obstacle ==0 && (tmpcell1->move[d]->bfs_iteration != bfs_mazeiteration || tmpcell1->bfs_g + tmpcell1->cost[d] < tmpcell1->move[d]->bfs_g)) 
#else
                    if (tmpcell1->move[d] && (tmpcell1->move[d]->bfs_iteration != bfs_mazeiteration || tmpcell1->bfs_g + tmpcell1->cost[d] < tmpcell1->move[d]->bfs_g)) 
#endif
                    {                           
                        if(tmpcell1->move[d]->bfs_iteration != bfs_mazeiteration) // generate for the 1st time in this search
                        {
                            tmpcell1->move[d]->bfs_iteration = bfs_mazeiteration; 
                            generate_end->generate_next = tmpcell1->move[d];
                            generate_end = tmpcell1->move[d];   
                            generate_end->generate_next = NULL;
                        }
                        tmpcell1->move[d]->bfs_g = tmpcell1->bfs_g + tmpcell1->cost[d] ;                
                        tmpcell1->move[d]->bfs_searchtree = tmpcell1;
                    }
            }
            
            if (generate_anchor->generate_next != NULL)
                generate_anchor = generate_anchor->generate_next;
            else
                break;
        } // end while
        
        target_new_destination = tmpcell1;
        target_new_destination->bfs_trace = NULL;
        while(tmpcell1 != mazegoal)
        {
            tmpcell1->bfs_searchtree->bfs_trace = tmpcell1;
            tmpcell1 = tmpcell1->bfs_searchtree;
        }
        mazegoal = mazegoal->bfs_trace;
    }
    mazegoal->in_path = 1;
    
#ifdef ADAPTIVE
#ifndef REVERSE  // search forward
    if(flag_target_moved1 == 1)
        keymodifier1++;     
#endif
#endif
    
    return;
}
//----------------------------------------------------------------------------------
void change_maze_traversability()
{
    cell *tmpcell;
    
#ifdef ADAPTIVE
    emptyheap2();    //  1. empty the queue for propagation
#endif
    
    for(i = 0; i < ch_number; i++)
    {
        tmpcell = change_point_array[i];
        // (block 0 -------> 1)     
        if(tmpcell->obstacle == 0) 
        {
            tmpcell->obstacle = 1;
            for (d = 0; d < DIRECTIONS; ++d) 
                if (tmpcell->move[d]) 
                {    
                    tmpcell->move[d] = NULL; 
                    tmpcell->succ[d]->move[reverse[d]] = NULL;            
                }    
        }
        else   // (unblock 1 -------> 0)
        {       
            tmpcell->obstacle = 0;
            tmpcell->g = LARGE; 
#ifdef ADAPTIVE
            tmpcell->h = LARGE;
            tmpcell->iteration  = mazeiteration1; // now mazeiteration1 == mazeiteration of the search just finished + 1
#endif
            
            for (d = 0; d < DIRECTIONS; ++d) 
            { 
                if(tmpcell->succ[d] && !tmpcell->succ[d]->obstacle) 
                {    
                    tmpcell->move[d] = tmpcell->succ[d]; 
                    tmpcell->succ[d]->move[reverse[d]] = tmpcell; 
#ifdef ADAPTIVE             
                    initialize_state(tmpcell->move[d]);                     
                    
                    if(tmpcell->move[d]->h + 1 < tmpcell->h)
                    {
                        tmpcell->h = tmpcell->move[d]->h + 1;
                    }
#endif              
                }
            }// end for d 
#ifdef ADAPTIVE     
            if(tmpcell->h != LARGE)
            {
                tmpcell->key1 = tmpcell->h;
                insertheap2(tmpcell); 
            }
            else // if(tmpcell1->h == LARGE)
            {
#ifndef REVERSE // forward  
                tmpcell->h = HA(tmpcell, mazegoal) ;    
#else
                tmpcell->h = HA(tmpcell, mazestart) ;
#endif
            }
#endif
        }// end else
    }// end for [i] 
}
//----------------------------------------------------------------------------------------------------------------------------
void consistent_procedure()
{
    while (topheap2() != NULL)  
    {
        tmpcell1 = popheap2();
        tmpcell1->over_progagated = mazeiteration1;
        
#ifdef STATISTICS
        ++counter_updates1;
#endif
        for (d = 0; d < DIRECTIONS; ++d)
        {
            if (tmpcell1->move[d] && tmpcell1->move[d]->over_progagated != mazeiteration1 && tmpcell1->move[d]->expanded > 0)
            {
                initialize_state(tmpcell1->move[d]);
                if(tmpcell1->move[d]->h > tmpcell1->h + 1)
                {
                    tmpcell1->move[d]->h = tmpcell1->h + 1;
                    tmpcell1->move[d]->key1 = tmpcell1->move[d]->h;
                    insertheap2(tmpcell1->move[d]);                 
                }                       
            }       
        } 
    }// end while
    return;
}
//----------------------------------------------------------------------------------------------------------------------------

int test_astar()
{
    gettimeofday(&tv01choose, NULL); 
#ifdef RANDOMMAZE
    newrandommaze();
#else
    newdfsmaze(WALLSTOREMOVE); 
#endif  
    gettimeofday(&tv02choose, NULL); 
    newrandomaze0  += 1.0*(tv02choose.tv_sec - tv01choose.tv_sec) + 1.0*(tv02choose.tv_usec - tv01choose.tv_usec)/1000000.0;  
    
    initialize_astar();
    
    while(mazestart != mazegoal)
    {
        
#ifdef UNKNOWN
        if(robot_steps0 == 0 || (flag_target_moved1 == 1 && mazegoal->path_iteration != mazeiteration1) || mazestart->trace->obstacle == 1)
#else // known env.
            if(robot_steps0 == 0 || (flag_target_moved1 == 1 && mazegoal->path_iteration != mazeiteration1) || flag_changed == 1)
#endif
            {
                if(!computeshortestpath_astar() )               
                {
                    //              printf("***********************************************************************\n");
                    printf("*   Astar when mazeiteration1 = %d,    no path possible   !!!         *\n", mazeiteration1);
                    //              printf("***********************************************************************\n");
                    return (0);
                }   
            }
#ifndef REVERSE     
            mazestart = mazestart->trace;   // robot moves one step
#else // reverse
            mazestart = mazestart->searchtree;   // robot moves one step
#endif          
            mazestart->in_path = 1;
            robot_steps0++; 
            
            
#ifdef ADAPTIVE
#ifdef REVERSE
            keymodifier1++;     
#endif
#endif
            
            if(mazestart == mazegoal)
                return;
            
#ifdef RANDOMLYMOVE         
            flag_target_moved1 = 0;
            if(robot_steps0 % SPEED != 0)
            {
                gettimeofday(&tv01choose, NULL); 
                target_move();
                gettimeofday(&tv02choose, NULL); 
                
                choose_target_togo0  += 1.0*(tv02choose.tv_sec - tv01choose.tv_sec) + 1.0*(tv02choose.tv_usec - tv01choose.tv_usec)/1000000.0; 
            }
            if(mazestart == mazegoal)
                return;
#endif
            
            
#ifndef UNKNOWN // for known env
            if(robot_steps0 % STEP == 0) // change the traversability of the map
            {
                gettimeofday(&tv01choose, NULL); 
                choose_maze_traversability();
                gettimeofday(&tv02choose, NULL); 
                
                choose_target_togo0  += 1.0*(tv02choose.tv_sec - tv01choose.tv_sec) + 1.0*(tv02choose.tv_usec - tv01choose.tv_usec)/1000000.0; 
#ifdef ADAPTIVE
                mazeiteration1++;  // 1. first ++, and when leave this function, we need to do --
                gettimeofday(&tv01change, NULL); 
                change_maze_traversability();
                gettimeofday(&tv02change, NULL);                    
                
                change_grid_time  += 1.0*(tv02change.tv_sec - tv01change.tv_sec) + 1.0*(tv02change.tv_usec - tv01change.tv_usec)/1000000.0;
                
                flag_changed = 1;
                consistent_procedure();
                mazeiteration1--;  // 2. first ++, and when leave this function, we need to do --
#else // A*
                gettimeofday(&tv01change, NULL); 
                change_maze_traversability();
                gettimeofday(&tv02change, NULL);                    
                
                change_grid_time  += 1.0*(tv02change.tv_sec - tv01change.tv_sec) + 1.0*(tv02change.tv_usec - tv01change.tv_usec)/1000000.0;
                
                flag_changed = 1;
#endif
            }       
#endif      
    }// end  while(mazestart != mazegoal)
    return (1);
}















//--------------------------------------------------------------------------------------
void call_astar()
{   


    
#ifdef ADAPTIVE 
    fp = fopen("test_aastar.out", "w");
#else
#ifdef TESTDIFFERENTIALASTAR
    fp = fopen("test_diff_astar.out", "w");
#else
    fp = fopen("test_astar.out", "w");
#endif
#endif
    
    fprintf(fp," MAZEWIDTH = %d,   case == %d\n", MAZEWIDTH, RUNS );
    
    for (RUN1 = 0; RUN1 < RUNS; ++RUN1)
    {
        printf("case == [%d] ___________________________________\n",RUN1);
        srand(RUN1);    
        gettimeofday(&tv01, NULL); 
        test_astar();
        gettimeofday(&tv02, NULL); 
        duration0  += 1.0*(tv02.tv_sec - tv01.tv_sec) + 1.0*(tv02.tv_usec - tv01.tv_usec)/1000000.0;    
        robotmoves_total1+= robot_steps0;
    }// end for RUN1S
    
    
    
    
    printf("******************************************\n");   
#ifdef TESTDIFFERENTIALASTAR
    printf("Test DIFFERENTIAL ASTAR  \n");
#else
#ifdef ADAPTIVE
    printf("Test Adaptive Astar \n");
#else
    printf("Test Astar \n");
#endif
#endif
    
#ifdef REVERSE
    printf("(Search REVERSE)\n");
#else
    printf("(Search FORWARD) \n");
#endif
    
    if(times_of_billion1 > 0)
        expansion_per_search =   ((float)1000000000 / (float)searches_astar * (float)times_of_billion1) + ((float)statexpanded1 / (float)searches_astar);
    else
        expansion_per_search = (float) statexpanded1 / (float)searches_astar;
    
#ifdef STATISTICS
    average_expansion_persearch = expansion_per_search;
    for(j = 1; j<= searches_astar; j++ )
    {
        variance_expansion_persearch += pow ((expansion_persearch1[j] - average_expansion_persearch), 2);
    }
    variance_expansion_persearch = pow((variance_expansion_persearch /  searches_astar), 0.5 );
    SDOM = variance_expansion_persearch /  pow(searches_astar, 0.5);
#endif
    
    
    
    
    printf("******************************************\n");   
    printf("CHANGE number KSWITCH == [%d] \n",   KSWITCH);
    printf("a star searches_astar / RUNS == %d \n",  searches_astar / RUNS);
    printf("a star expansions / search == [ %f ]\n", expansion_per_search);
    printf("a star propagates / search == [ %d ]\n", counter_updates1 / searches_astar);
    printf("a star SDOM of expansion / search == %f \n", SDOM);
    printf("a star robot moved / case == %d \n", robotmoves_total1 / RUNS);
    printf("a star target moved / case == %d \n",   target_steps  / RUNS);
    printf("a star total time ==  %f \n", duration0);
    printf("a star newrandomaze time ==  %f \n", newrandomaze0);    
    printf("whole time/persearch == %f \n",   duration0 / searches_astar    );
    printf("a start newrandomze time/persearch == %f \n",  newrandomaze0 / searches_astar    );
    printf("a start choose_target_togo0 time/persearch == %f \n",  choose_target_togo0 / searches_astar    );
    printf("a start change_grid_time/persearch == %f \n",  change_grid_time / searches_astar    );
    printf("pure time (include change)/persearch == %f \n",   (duration0 - newrandomaze0 - choose_target_togo0 )  / searches_astar    );
    printf("pure time (exclude change)/persearch == %f \n",   (duration0 - newrandomaze0 - choose_target_togo0 - change_grid_time)  / searches_astar    );
    return;
}
#endif
