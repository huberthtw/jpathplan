#include "include.h"
#include "heap.h"



int leftchild; 
int rightchild;
int least2;
int i, j, d;


#ifdef INFORMEDSEARCH
#define HA(from,to) ( abs( (from)->y - (to)->y  ) + abs( (from)->x - (to)->x )   ) 
#else
#define HA(from,to)  ( 0 )
#endif

    cell *heap[HEAPSIZE];
    int heapsize = 0;
    int keylength = 3;

    int keyless(cell *cell1, cell* cell2)
    {
        int keyindex;

        for (keyindex = 0; keyindex < keylength; ++keyindex)
        {
        if (cell1->key[keyindex] < cell2->key[keyindex])
            return 1;
        else if (cell1->key[keyindex] > cell2->key[keyindex])
            return 0;
        }
        return 0;
    }

    int testheap()
    {
        int d;

        for (d = heapsize/2; d > 0; d--)
        {
        assert(!keyless(heap[2*d],heap[d]));
        if (2*d+1 <= heapsize)
            assert(!keyless(heap[2*d+1],heap[d]));
        }
    return 0;
    }

    void percolatedown(int hole, cell *tmp)
    {
        int child;

        if (heapsize != 0)
        {
        for (; 2*hole <= heapsize; hole = child)
            {
            child = 2*hole;
            if (child != heapsize && keyless(heap[child+1], heap[child]))
            ++child;
            if (keyless(heap[child], tmp))
                {
            heap[hole] = heap[child];
            heap[hole]->heapindex = hole;
                }
            else
            break;
            }
        heap[hole] = tmp;
        heap[hole]->heapindex = hole;
        }
    }

    void percolateup(int hole, cell *tmp)
    {
        if (heapsize != 0)
        {
        for (; hole > 1 && keyless(tmp, heap[hole/2]); hole /= 2)
            {
            heap[hole] = heap[hole/2];
            heap[hole]->heapindex = hole;
            }
        heap[hole] = tmp;
        heap[hole]->heapindex = hole;
        }
    }

    void percolateupordown(int hole, cell *tmp)
    {
        if (heapsize != 0)
        {
        if (hole > 1 && keyless(tmp, heap[hole/2]))
            percolateup(hole, tmp);
        else
            percolatedown(hole, tmp);
        }
    }

    void emptyheap(int length)
    {
        keylength = length;
        heapsize = 0;
    }

    cell *topheap()
    {
        if (heapsize == 0)
        return NULL;
        return heap[1];
    }

    void deleteheap(cell *thiscell)
    {
        if (thiscell->heapindex != 0 && thiscell->generated == mazeiteration)
        {
        percolateupordown(thiscell->heapindex, heap[heapsize--]);
        thiscell->heapindex = 0;
        }
    }

    cell* popheap()
    {
        cell *thiscell;

        if (heapsize == 0)
        return NULL;
        thiscell = heap[1];
        thiscell->heapindex = 0;
        percolatedown(1, heap[heapsize--]);
        return thiscell;
    }

    void insertheap(cell *thiscell)
    {
        int hole;

        if (thiscell->heapindex == 0 || thiscell->generated != mazeiteration)
        {
        thiscell->heapindex = 0;
    #ifdef DEBUG
        assert(heapsize < HEAPSIZE-1);
    #endif
        percolateup(++heapsize, thiscell);
        }
        else
        percolateupordown(thiscell->heapindex, heap[thiscell->heapindex]);
    }

    void printheap()
    {
        for(i = 1; i <= heapsize; i++)
        {
            printf("heap[%d] == [%d][%d], rhs = [%d], g = [%d] \n", i, heap[i]->y, heap[i]->x, heap[i]->rhs, heap[i]->g);   
        //  fprintf(fp,"heap[%d] == [%d][%d], rhs = [%d], g = [%d] \n", i, heap[i]->y, heap[i]->x, heap[i]->rhs, heap[i]->g);   
        }
    }

/* --------------------------    Binary Heap   -------------------------------------------- */
    cell *heap2[HEAPSIZE];
    int heapsize2 = 0;
    int bottom_index_start = 0;
    int statpercolated2 = 0;

    cell * temp8;
    /* --------------------------------------------------------------- */
    void percolatedown2(int hole, cell *tmp)
    {
      int child;

      if (heapsize2 != 0)
        {
            for (; 2*hole <= heapsize2; hole = child)
            {
              child = 2*hole;
              if (child != heapsize2 && heap2[child+1]->key1 < heap2[child]->key1)
                ++child;
              if (heap2[child]->key1 < tmp->key1)
                {
                  heap2[hole] = heap2[child];
                  heap2[hole]->heapindex = hole;
    //            ++statpercolated2;
                }
              else
                break;
            } // end for
          heap2[hole] = tmp;
          heap2[hole]->heapindex = hole;
        }
    }
    /* --------------------------------------------------------------- */
    void percolateup2(int hole, cell *tmp)
    {
      if (heapsize2 != 0)
        {
          for (; hole > 1 && tmp->key1 < heap2[hole/2]->key1; hole /= 2)
        {
          heap2[hole] = heap2[hole/2];
          heap2[hole]->heapindex = hole;
    //    ++statpercolated2;
        }  
          heap2[hole] = tmp;
          heap2[hole]->heapindex = hole;
        }
    }
    /* --------------------------------------------------------------- */
    void percolateupordown2(int hole, cell *tmp)
    {
      if (heapsize2 != 0)
        {
          if (hole > 1 && heap2[hole/2]->key1 > tmp->key1)
            percolateup2(hole, tmp);
          else
            percolatedown2(hole, tmp);
        }
    }
    /* --------------------------------------------------------------- */
    void insertheap2(cell *thiscell)
    {
      int hole;

      if (thiscell->heapindex == 0)
        { 
      //  assert(heapsize2 < HEAPSIZE-1);
          percolateup2(++heapsize2, thiscell);
        }
      else
        percolateupordown2(thiscell->heapindex, heap2[thiscell->heapindex]);
    }
    /* --------------------------------------------------------------- */
    void deleteheap2(cell *thiscell)
    {
      if (thiscell->heapindex != 0)
        {
          percolateupordown2(thiscell->heapindex, heap2[heapsize2--]);
          thiscell->heapindex = 0;
        }
    }
    /* --------------------------------------------------------------- */
    cell *topheap2()
    {
      if (heapsize2 == 0)
        return NULL;
      return heap2[1];
    }
    /* --------------------------------------------------------------- */
    void emptyheap2()
    {
      int i;

      for (i = 1; i <= heapsize2; ++i)
        heap2[i]->heapindex = 0;
      heapsize2 = 0;
    }
    /* --------------------------------------------------------------- */
    cell* popheap2()
    {
        cell *thiscell;

        if (heapsize2 == 0)
            return NULL;
        thiscell = heap2[1];
        thiscell->heapindex = 0;
        percolatedown2(1, heap2[heapsize2--]);
        return thiscell;
    }

/* --------------------------    Binary Heap end-------------------------------------------- */

void print_heap()
{   
    for(i = 1; i <= heapsize2; i++)
    {
        printf("[%d] ==[%d][%d], ->heapindex == [%d] \n", i, heap2[i]->y, heap2[i]->x,  heap2[i]->heapindex );
        fprintf(fp, "[%d] ==[%d][%d], ->heapindex == [%d]   \n", i, heap2[i]->y, heap2[i]->x, heap2[i]->heapindex );
    }
}

//---------------------------------------------------------------------------------------------------------
void insert_array_heap(cell *thiscell) 
{ 
        heap2[++heapsize2] = thiscell; 
        thiscell->heapindex = heapsize2;

} 

//------------------------------------------------------------------------------------------------------------
void undo_opencell(cell *thiscell)
{
    if(thiscell->heapindex > 0)
    {
        thiscell->searchtree = NULL;
        
        heap2[heapsize2]->heapindex = thiscell->heapindex;
        heap2[thiscell->heapindex] = heap2[heapsize2];
        thiscell->heapindex = 0;
        heap2[heapsize2] = NULL;
        heapsize2--;
    }
return;
}
//------------------------------------------------------------------------------------------------------------
void get_openlist_ready(int mazeiteration3)
{
    mazestart->searchtree = mazestart;
    for(j = 1; j <= heapsize2; j++)
        heap2[j]->expanded = 0;     

    for(j = 1; j <= heapsize2; j++)
    {
        heap2[j]->iteration = mazeiteration3 + 1;
        heap2[j]->g = LARGE;
        for(d = 0; d < 4; d++)
        {
            if(heap2[j]->move[d] && heap2[j]->move[d]->expanded > 0 && heap2[j]->move[d]->searchtree)
            {
                heap2[j]->move[d]->expanded = mazeiteration3 + 1;
                if (heap2[j]->g > heap2[j]->move[d]->g + heap2[j]->cost[d])
                {
                    heap2[j]->g = heap2[j]->move[d]->g + heap2[j]->cost[d];
                    heap2[j]->searchtree = heap2[j]->move[d];
                }
            }   
        } // end for d

        heap2[j]->h =  HA(heap2[j], mazegoal);  
#ifdef TIELARGE
        heap2[j]->key1 = (heap2[j]->g + heap2[j]->h) * BASE - heap2[j]->g;
#else
        heap2[j]->key1 = (heap2[j]->g + heap2[j]->h) * BASE + heap2[j]->g;
#endif

        heap2[j]->child_number = 0;
    }
    mazestart->searchtree = NULL;
return;
}

/* --------------------------------------------------------------- */ 
void heapify (int i) 
{ 
    leftchild = 2 * i; 
    rightchild = 2 * i + 1; 

    if(leftchild <= heapsize2 && heap2[leftchild]->key1 < heap2[i]->key1) 
    least2 = leftchild; 
    else  
    least2 = i; 

    if(rightchild <= heapsize2 &&  heap2[rightchild]->key1 < heap2[least2]->key1) 
    least2 = rightchild; 

    if(least2 != i) 
    { 
    temp8 = heap2[i]; 
    heap2[i] = heap2[least2]; 
    heap2[least2] = temp8; 
    
    heapify (least2); 
    } 
} 
/* --------------------------------------------------------------- */ 
void heapify_fringe(int mazeiteration3) 
{   
    for(j = heapsize2 / 2; j >= 1; j--) 
    heapify(j);      

    for(j = 1; j <= heapsize2; j++) 
    heap2[j]->heapindex = j; 

} 
