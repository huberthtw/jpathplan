//1. In this version, there is only one version of cell, namely, no *cell1
//2. newrandomaze() is unified


#ifndef INCLUDEH
#define INCLUDEH

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>



//#define TESTASTAR             // test A star 
//#define TESTDIFFERENTIALASTAR // test Differential A*, runs together with A* 
//#define ADAPTIVE  


//#define TESTDSTARLITE          // test MT-D*Lite  (Xiaoxun's version)    
#define TESTGDSTAR              // test Generalized D* (Sven's version)



#define TIELARGE
#define RANDOMLYMOVE
//#define REVERSE          
#define RUNS 10            // number of test cases         
 
#define HEAPIFY            // must define
#define MAZEWIDTH  1000    // has to be an odd number for maze (not torus)        
#define MAZEHEIGHT 1000    // has to be an odd number for maze (not torus)
#define MAZEDENSITY 0.25    
#define SPEED 10           // AGENT : TARGET = 10 : 9
#define STEP  1           // After each "STEP" of the agent, we change the environment
#define BFS_NUMBER 100


#define KSWITCH 10                  // change KSWITCH cells from 1->0 and 0->1
#define ZOOM 1
#define STATISTICS     /* should disable this for timing */
//#define DISPLAY



//_________________________________________________________________________________________________________
#define RANDOMMAZE               // if disable this, must choose odd number for the size of the maze (101*101 e.g) 
#define CASE_1                 /*  Robot navigates in known (dynamically changing)maze (RANDOMMAZE), so need to disable #UNKNOWN*/ 
#define INFORMEDSEARCH           /* use heuristic rather than zero heuristics  */
#define LARGE  10000000
#define BASE   100000
#define ALLMAXSEARCHES 10000000
#define WALLSTOREMOVE 4           /* number of walls to remove if RANDOMMAZE is NOT defined - infinite loop if too large */
//#define DEBUG                   /* whether debugging is on - debugging takes time but performs various checks           */
#define RANDOMSTARTGOAL           /* whether the start and goal state are drawn randomly                                 */
#define STARTX 1                  /* x coordinate of the start cell                                                      */
#define STARTY 1                  /* y coordinate of the start cell                                                      */
#define GOALX 4                   /* x coordinate of the goal  cell                                                       */
#define GOALY 4                   /* y coordinate of the goal  cell                                                       */
#define TIEBREAKING 2             /* D* lite 0: no tie breaking, 1: towards smaller g-values; 2: towards larger g-values */

#define DIRECTION  4
#define DIRECTIONS 4

static int dx[DIRECTIONS] = {1, 0, -1,  0};
static int dy[DIRECTIONS] = {0, 1,  0, -1};
static int reverse[DIRECTIONS] = {2, 3, 0, 1};


#ifdef INFORMEDSEARCH
#define HA(from,to) ( abs( (from)->y - (to)->y  ) + abs( (from)->x - (to)->x )   ) 
#else
#define HA(from,to)  ( 0 )
#endif


long int RUN1;
FILE *fp;    

#define max(x,y) ( (x) > (y) ? (x) : (y) )
#define min(x,y) ( (x) < (y) ? (x) : (y) )

#endif
