#include "include.h"
#include "heap.h"
#include "maze.h"
#include "stdio.h"
#include "gdstar.h"

#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>



#ifdef TESTGDSTAR

#define H(from) (abs((from)->y - (mazegoal)->y) + abs((from)->x - (mazegoal)->x))


short flag_target_moved1 = 0;
short flag_not_end;
short d, d1;
int i, j;
int RUN;
int keymodifier = 0;
int times_of_billion4 = 0;
int search_iteration = 0;
int bfs_mazeiteration = 0;
int robot_steps0 = 0;
long int statexpanded_thissearch;   
long int searches_gdstar = 0;
long int statexpanded = 0;
long int expansionscount;
long int statesexpanded;
long int robotmoves_total = 0;
long int target_steps = 0;
unsigned int undo_index;
float time_dstar_initialize = 0;
float time_gdstar = 0;

cell* undo_end;
cell* tmpcell, *tmpcell1, *tmpcell2, *current_cell;
cell* lastcell;
cell* last_search_start;
cell* last_search_goal;
cell goaltmpcell, oldtmpcell;
cell* undolist[MAZEWIDTH * MAZEHEIGHT];

double undo_SDOM = 0;
float average_undo_persearch;
float variance_undo_persearch;
unsigned int undo_cells_thiscase;
unsigned long int sum_undo = 0;
float undo_persearch2[ALLMAXSEARCHES];
int expansion_persearch[ALLMAXSEARCHES];

double duration0 = 0;
double choose0 = 0;
double change0 = 0;
double newrandomaze0 = 0;
double choose_target_togo0 = 0; 
double change_grid_time = 0; 

struct timeval tv01, tv02, tv01choose, tv02choose, tv01change, tv02change, tv33, tv44,  tv33a, tv44a, tv33b, tv44b, tv33c, tv44c;


void initialize()
{
    search_iteration = 0;
    flag_changed = 0;
    flag_target_moved1 = 0;
    undo_cells_thiscase = 0;
    
    bfs_mazeiteration = 0;
    robot_steps0 = 0;
    last_search_start = mazestart;
    last_search_goal = mazegoal;
    
    ++mazeiteration;
    keymodifier = 0;
    mazestart->g = LARGE;
    mazestart->rhs = 0;
#ifdef TIEBREAKING
    emptyheap(3);
    mazestart->key[0] = H(mazestart);
    mazestart->key[1] = H(mazestart) + 1;
    mazestart->key[2] = H(mazestart);
#else
    emptyheap(2);
    mazestart->key[0] = H(mazestart);
    mazestart->key[1] = 0;
#endif
    mazestart->searchtree = NULL;
    mazestart->generated = mazeiteration;
    insertheap(mazestart);
    mazegoal->g = LARGE;
    mazegoal->rhs = LARGE;
    mazegoal->searchtree = NULL;
    mazegoal->generated = mazeiteration;
}


void initializecell(cell *thiscell)
{
    if (thiscell->generated != mazeiteration)
    {
        thiscell->g = LARGE;
        thiscell->rhs = LARGE;
        thiscell->searchtree = NULL;
        thiscell->generated = mazeiteration;
    }
}

void updatecell(cell *thiscell)
{
    if (thiscell->g < thiscell->rhs)
    {
#ifdef TIEBREAKING
        thiscell->key[0] = thiscell->g + H(thiscell) + keymodifier;
        thiscell->key[1] = thiscell->g + H(thiscell) + keymodifier;
        thiscell->key[2] = thiscell->g;
#else
        thiscell->key[0] = thiscell->g + H(thiscell) + keymodifier;
        thiscell->key[1] = thiscell->g; 
#endif
        insertheap(thiscell);
    }
    else if (thiscell->g > thiscell->rhs)
    {
#ifdef TIEBREAKING
        thiscell->key[0] = thiscell->rhs + H(thiscell) + keymodifier;
        thiscell->key[1] = thiscell->rhs + H(thiscell) + keymodifier + 1;
        thiscell->key[2] = H(thiscell) + keymodifier;
#else
        thiscell->key[0] = thiscell->rhs + H(thiscell) + keymodifier;
        thiscell->key[1] = thiscell->rhs;
#endif
        insertheap(thiscell);
    }
    else 
        deleteheap(thiscell);
}

void updatekey(cell *thiscell)
{
    if (thiscell->g < thiscell->rhs)
    {
#ifdef TIEBREAKING
        thiscell->key[0] = thiscell->g + H(thiscell) + keymodifier;
        thiscell->key[1] = thiscell->g + H(thiscell) + keymodifier;
        thiscell->key[2] = thiscell->g;
#else
        thiscell->key[0] = thiscell->g + H(thiscell) + keymodifier;
        thiscell->key[1] = thiscell->g; 
#endif
    }
    else 
    {
#ifdef TIEBREAKING
        thiscell->key[0] = thiscell->rhs + H(thiscell) + keymodifier;
        thiscell->key[1] = thiscell->rhs + H(thiscell) + keymodifier + 1;
        thiscell->key[2] = H(thiscell) + keymodifier;
#else
        thiscell->key[0] = thiscell->rhs + H(thiscell) + keymodifier;
        thiscell->key[1] = thiscell->rhs;
#endif
    }
}

void updaterhs(cell *thiscell)
{
    short d;
    
    thiscell->rhs = LARGE;
    thiscell->searchtree = NULL;
    for (d = 0; d < DIRECTIONS; ++d)
    {
        if (thiscell->move[d] && thiscell->move[d]->generated == mazeiteration && thiscell->rhs > thiscell->move[d]->g + 1)
        {
            thiscell->rhs = thiscell->move[d]->g + 1;
            thiscell->searchtree = thiscell->move[d];
        }
    }
    updatecell(thiscell);
}
//--------------------------------------------------------------------------------------------------------------------
int computeshortestpath()
{
    searches_gdstar++;
#ifdef STATISTICS
    statexpanded_thissearch = 0;
    search_iteration++;
#endif
    
    flag_changed = 0;
    last_search_start = mazestart;
    initializecell(mazegoal);
        
    
#ifdef TIEBREAKING
    if (mazegoal->g < mazegoal->rhs)
    {
        goaltmpcell.key[0] = mazegoal->g + keymodifier;
        goaltmpcell.key[1] = mazegoal->g + keymodifier;
        goaltmpcell.key[2] = mazegoal->g;
    }
    else
    {
        goaltmpcell.key[0] = mazegoal->rhs + keymodifier;
        goaltmpcell.key[1] = mazegoal->rhs + keymodifier + 1;
        goaltmpcell.key[2] = keymodifier;
    }
#else
    if (mazegoal->g < mazegoal->rhs)
    {
        goaltmpcell.key[0] = mazegoal->g + keymodifier;
        goaltmpcell.key[1] = mazegoal->g;
    }
    else
    {
        goaltmpcell.key[0] = mazegoal->rhs + keymodifier;
        goaltmpcell.key[1] = mazegoal->rhs;
    }
#endif
    
    while (topheap() && (mazegoal->rhs > mazegoal->g || keyless(topheap(), &goaltmpcell)))
    {
        tmpcell1 = topheap();       
        oldtmpcell.key[0] = tmpcell1->key[0];
        oldtmpcell.key[1] = tmpcell1->key[1];
#ifdef TIEBREAKING
        oldtmpcell.key[2] = tmpcell1->key[2];
#endif
        updatekey(tmpcell1); 
        
        if (keyless(&oldtmpcell, tmpcell1))
        {
            updatecell(tmpcell1);           
        }
        else if (tmpcell1->g > tmpcell1->rhs)
        {
#ifdef STATISTICS
            statexpanded_thissearch++;
#endif
            tmpcell1->g = tmpcell1->rhs;
            deleteheap(tmpcell1);           
            for (d = 0; d < DIRECTIONS; ++d)
            {
                if (tmpcell1->move[d])
                {
                    tmpcell2 = tmpcell1->move[d];
                    initializecell(tmpcell2);
                    if (tmpcell2 != mazestart && tmpcell2->rhs > tmpcell1->g + 1)
                    {
                        tmpcell2->rhs = tmpcell1->g + 1;
                        tmpcell2->searchtree = tmpcell1;
                        updatecell(tmpcell2);
                    }
                }
            }
        }
        else
        {
#ifdef STATISTICS
            statexpanded_thissearch++;
#endif
            tmpcell1->g = LARGE;
            updatecell(tmpcell1);
            
            for (d = 0; d < DIRECTIONS; ++d) 
            {
                if (tmpcell1->move[d])
                {
                    tmpcell2 = tmpcell1->move[d];
                    initializecell(tmpcell2);
                    if (tmpcell2 != mazestart && tmpcell2->searchtree == tmpcell1)
                    {
                        updaterhs(tmpcell2);        
                    }
                }
            }
        } // end else
        //--------------------------------------------
#ifdef TIEBREAKING
        if (mazegoal->g < mazegoal->rhs)
        {
            goaltmpcell.key[0] = mazegoal->g + keymodifier;
            goaltmpcell.key[1] = mazegoal->g + keymodifier;
            goaltmpcell.key[2] = mazegoal->g;
        }
        else
        {
            goaltmpcell.key[0] = mazegoal->rhs + keymodifier;
            goaltmpcell.key[1] = mazegoal->rhs + keymodifier + 1;
            goaltmpcell.key[2] = keymodifier;
        }    
#else
        if (mazegoal->g < mazegoal->rhs)
        {
            goaltmpcell.key[0] = mazegoal->g + keymodifier;
            goaltmpcell.key[1] = mazegoal->g;
        }
        else
        {
            goaltmpcell.key[0] = mazegoal->rhs + keymodifier;
            goaltmpcell.key[1] = mazegoal->rhs;
        }
#endif
        //------------------------------------------------
            } // end while
#ifdef STATISTICS
            expansion_persearch[searches_gdstar] = statexpanded_thissearch;
            expansionscount += statexpanded_thissearch; //----------2009.05.21------------------------------------------
            if(expansionscount >= 1000000000)
            {
                expansionscount = expansionscount - 1000000000;
                times_of_billion4++;
            }
#endif
            
            
            /////////////////////////////////////////////////////////
#ifdef RANDOMLYMOVE // in MTS, D* lite search forwards, so need to identify a path from the goal back to the start.
            if(mazegoal->rhs != LARGE)  // path exists
            {
                mazegoal->trace = NULL;   // tracing back a path from the goal back to the start
                tmpcell = mazegoal; 
                tmpcell->path_iteration = searches_gdstar;
                if(search_iteration == 1)  // if this is the first iteration
                {
                    mazestart->in_path = 1;
                    mazegoal->in_path = 1;
                    while(tmpcell != mazestart)
                    {
                        tmpcell->searchtree->trace = tmpcell;
                        tmpcell = tmpcell->searchtree;
                        tmpcell->in_path = 1;
                        tmpcell->path_iteration = searches_gdstar;
                    }
                }
                else
                {
                    while(tmpcell != mazestart)
                    {
                        tmpcell->searchtree->trace = tmpcell;
                        tmpcell = tmpcell->searchtree;
                        tmpcell->path_iteration = searches_gdstar;
                    }       
                }
                return (0);
            }
#endif
            /////////////////////////////////////////////////////////
            return (mazegoal->rhs == LARGE);
}
//------------------------------------------------------------------
// updatemaze(cell *robot) is to update the action costs for the newly detected obstacles  (0 --> 1 only)
// it is for un-known environments only.
void updatemaze(cell *robot)
{
    short d1, d2;
    cell *tmpcell;
    
    
    
    for (d1 = 0; d1 < DIRECTIONS; ++d1)
    {
        if (robot->move[d1] && robot->move[d1]->obstacle)
        {
            tmpcell = robot->move[d1];
            initializecell(tmpcell);
            for (d2 = 0; d2 < DIRECTIONS; ++d2)
            {
                if (tmpcell->move[d2])
                {
                    tmpcell->move[d2] = NULL;
                    tmpcell->succ[d2]->move[reverse[d2]] = NULL;
                    initializecell(tmpcell->succ[d2]);
                    if (tmpcell->succ[d2] != mazestart && tmpcell->succ[d2]->searchtree == tmpcell)
                        updaterhs(tmpcell->succ[d2]);
                }
            }
            if (tmpcell != mazestart)
            {
                tmpcell->rhs = LARGE;
                updatecell(tmpcell);
            }
        }
    }
    return;
}

//--------------------------------------------------------------------------------------------------
void target_move()  // for D* Lite
{
    int bfs_expanded_number;
    int flag_target_can_move;
    
    
    target_steps++;
    flag_target_moved1 = 1;
    
    bfs_expanded_number = 0;
    bfs_mazeiteration++;
    
    if(mazegoal->bfs_trace &&  mazegoal->bfs_trace->obstacle == 0)
    {
        mazegoal = mazegoal->bfs_trace;
    }
    else // we need to run BFS to identify a path for the target to go
    {
        
        
        mazegoal->bfs_g = 0;
        mazegoal->bfs_iteration = bfs_mazeiteration;
        mazegoal->bfs_searchtree = NULL;
        
        generate_anchor = mazegoal;
        generate_end = mazegoal;
        generate_end->generate_next = NULL; 
        
#ifdef UNKNOWN
        // EMPTY
#else // known env
        while (generate_anchor != NULL)
        {
            tmpcell1 = generate_anchor;    // prepare to expand.
            bfs_expanded_number++;
            if(bfs_expanded_number == BFS_NUMBER)
                break;
            
            for (d = 0; d < DIRECTIONS; ++d)
            {         
                if (tmpcell1->move[d] && tmpcell1->move[d]->bfs_iteration != bfs_mazeiteration)   //|| tmpcell1->bfs_g + tmpcell1->cost[d] < tmpcell1->move[d]->bfs_g)) 
                {                           
                    if(tmpcell1->move[d]->bfs_iteration != bfs_mazeiteration) // generate for the 1st time in this search
                    {
                        tmpcell1->move[d]->bfs_iteration = bfs_mazeiteration; 
                        generate_end->generate_next = tmpcell1->move[d];
                        generate_end = tmpcell1->move[d];   
                        generate_end->generate_next = NULL;
                    }
                    tmpcell1->move[d]->bfs_g = tmpcell1->bfs_g + tmpcell1->cost[d] ;                
                    tmpcell1->move[d]->bfs_searchtree = tmpcell1;
                }
            }
            
            if (generate_anchor->generate_next != NULL)
                generate_anchor = generate_anchor->generate_next;
            else
                break;  // before reach bfs_number, there is not enough empty cells in the maze, so break;
        } // end while
#endif
        
        
        target_new_destination = tmpcell1;
        target_new_destination->bfs_trace = NULL;
        while(tmpcell1 != mazegoal)
        {
            tmpcell1->bfs_searchtree->bfs_trace = tmpcell1;
            tmpcell1 = tmpcell1->bfs_searchtree;
        }
        mazegoal = mazegoal->bfs_trace;
    }
    
    mazegoal->in_path = 1;
    
    return;
}
//--------------------------------------------------------------------------------------------------
void change_maze_traversability()
{
    
    for(i = 0; i < ch_number; i++)
    {
        tmpcell = change_point_array[i];
        
        if(tmpcell->obstacle == 0)      // (block 0 -------> 1)
        {
            tmpcell->obstacle = 1;
            if(tmpcell->generated != mazeiteration)// tmpcell has not been generated in this test case, so just update the graph, no rhs-update needed.
            {
                for (d = 0; d < DIRECTIONS; ++d)            
                    if(tmpcell->move[d])
                    {
                        tmpcell->move[d] = NULL;
                        tmpcell->succ[d]->move[reverse[d]] = NULL;
                    }
            }
            else//1. if(tmpcell->generated == mazeiteration) // need to update rhs-value for the successors of tmpcell, because tmpcell was generated in this test case
                /**/        {   
                for (d = 0; d < DIRECTIONS; ++d)
                {
                    if(tmpcell->move[d])
                    {
                        tmpcell->move[d] = NULL;
                        tmpcell->succ[d]->move[reverse[d]] = NULL;
                        
                        initializecell(tmpcell->succ[d]);
                        if (tmpcell->succ[d] != mazestart && tmpcell->succ[d]->searchtree == tmpcell)
                            updaterhs(tmpcell->succ[d]);                
                    }
                }           
                if (tmpcell != mazestart) 
                {
                    tmpcell->rhs = LARGE;
                    tmpcell->g   = LARGE;
                    tmpcell->searchtree = NULL;
                    deleteheap(tmpcell);
                    //  tmpcell->generated = 0; // (1) this step has to be after deleteheap(tmpcell).  (2) set tmpcell->generated = 0 to indicate that this obstacle was taken out from the search.
                }       
            }// end else 1. 
        }
        else   // (unblock 1 -------> 0)
        {
            tmpcell->obstacle = 0;
            initializecell(tmpcell);            
            for (d = 0; d < DIRECTIONS; ++d) 
            { 
                if(tmpcell->succ[d] && !tmpcell->succ[d]->obstacle) 
                {    
                    tmpcell->move[d] = tmpcell->succ[d]; 
                    tmpcell->succ[d]->move[reverse[d]] = tmpcell;               
                }                
            }
            if(tmpcell != mazestart) // can also be optimized here, since tmpcell can not be mazestart (set 1-->0 for mazestart is impossible) 
            {
                updaterhs(tmpcell); 
                
                if(tmpcell->rhs == LARGE)
                    tmpcell->generated = 0;
            }
        }// end else
    }// end for (i) 
    return;
}
//----------------------------------------------------------------------------------------------------------






















//int main(int argc, char *argv[])
// search from the mazestart to mazegoal (mazegoal is the current cell of the agent)
int test_gdstar()
{
    int k, l;
    cell *lastcell;
    
    
    gettimeofday(&tv33c, NULL);
#ifdef RANDOMMAZE   
    newrandommaze();
#else
    newdfsmaze(WALLSTOREMOVE);
#endif
    gettimeofday(&tv44c, NULL); 
    time_dstar_initialize += 1.0*(tv44c.tv_sec - tv33c.tv_sec) + 1.0*(tv44c.tv_usec - tv33c.tv_usec)/1000000.0;  
    
    initialize();
    //      fflush(stdout);
    lastcell = mazegoal;
    
    if (computeshortestpath())    // 1st call computepath for 1st searchiteration
    {
        printf("* when search == %d, no path exists * \n",  search_iteration);
        return 0;
    }   
    
    
    
    while (mazestart != mazegoal) // while 1.
    {   
#ifdef UNKNOWN
//EMPTY
#else // known maze_____________________________________________________________________________________________________
        mazestart_old = mazestart;
        mazestart = mazestart->trace;  // mazestart is the agent, so move the agent to agent->trace
        mazestart->searchtree = NULL;
        mazestart->in_path = 1;
        robot_steps0++; 
        if(mazestart == mazegoal)
            return (1);
        updaterhs(mazestart_old);
    #ifdef RANDOMLYMOVE                 // must define MTS  
        flag_target_moved1 = 0;
        if(robot_steps0 % SPEED != 0)
        {
            gettimeofday(&tv01choose, NULL); 
            target_move();
            gettimeofday(&tv02choose, NULL);                
            choose_target_togo0  += 1.0*(tv02choose.tv_sec - tv01choose.tv_sec) + 1.0*(tv02choose.tv_usec - tv01choose.tv_usec)/1000000.0; 
        }
        if(mazestart == mazegoal)
            return (1);
    #endif
        
        if(robot_steps0 % STEP == 0) // change the traversability of the map
        {
            gettimeofday(&tv01choose, NULL); 
            choose_maze_traversability();
            gettimeofday(&tv02choose, NULL); 
            choose_target_togo0  += 1.0*(tv02choose.tv_sec - tv01choose.tv_sec) + 1.0*(tv02choose.tv_usec - tv01choose.tv_usec)/1000000.0; 
            
            
            gettimeofday(&tv01change, NULL); 
            change_maze_traversability();
            flag_changed = 1;
            gettimeofday(&tv02change, NULL);                                        
            change_grid_time  += 1.0*(tv02change.tv_sec - tv01change.tv_sec) + 1.0*(tv02change.tv_usec - tv01change.tv_usec)/1000000.0;
        }
        
        
        // if (1) target moved off the shortest path OR (2) terrain changed
        if((flag_target_moved1 == 1 && mazegoal->path_iteration != searches_gdstar) || flag_changed == 1)
        {
            
            keymodifier += H(last_search_goal);
            last_search_goal = mazegoal;
            if (computeshortestpath())       // call for 2nd search to the n-th search
            {
                printf("* when search == %d, no path exists * \n",  search_iteration);
                return 0;
            }
        }

#endif
        }// end while 1.
        return (1);
}





















/*----------------------------------------------------------------------------------*/
void call_gdstar()
{
    long int j;
    float average_expansion_persearch = 0;
    float variance_expansion_persearch = 0;
    float SDOM = 0;
    unsigned long int total_undos = 0;
    unsigned long int total_searches = 0;
    
   
    fp = fopen("test20090723.out", "w");
    fprintf(fp," MAZEWIDTH = %d,  case == %d\n", MAZEWIDTH, RUNS );
    
    for (RUN = 0; RUN < RUNS; ++RUN)
    {
        printf("case == [%d] ___________________________________\n",RUN);
        srand(RUN);
        gettimeofday(&tv33, NULL); 
        test_gdstar();
        gettimeofday(&tv44, NULL); 
        
        time_gdstar += 1.0*(tv44.tv_sec - tv33.tv_sec) + 1.0*(tv44.tv_usec - tv33.tv_usec)/1000000.0;  
        
        robotmoves_total += robot_steps0; 
        undo_persearch2[RUN] = (float) (undo_cells_thiscase /  search_iteration); 
        
        total_undos    += undo_cells_thiscase;
        total_searches += search_iteration;     
    }
    
    
    
#ifdef STATISTICS
    if(times_of_billion4 > 0)
        average_expansion_persearch =   ((float)1000000000 / (float)searches_gdstar * (float)times_of_billion4) + ((float)expansionscount / (float)searches_gdstar);
    else
        average_expansion_persearch = (float) expansionscount / (float)searches_gdstar;
    
    for(j = 1; j<= searches_gdstar; j++ )
        variance_expansion_persearch += pow ((expansion_persearch[j] - average_expansion_persearch), 2);
    variance_expansion_persearch = pow((variance_expansion_persearch /  searches_gdstar), 0.5 );
    SDOM = variance_expansion_persearch /  pow(searches_gdstar, 0.5);
    
    sum_undo = 0;
    for(j = 0; j < RUNS; j++ )
        sum_undo += undo_persearch2[j];
    average_undo_persearch = (float) (sum_undo / RUNS);
    for(j = 0; j < RUNS; j++ )
        variance_undo_persearch += pow ((undo_persearch2[j] - average_undo_persearch), 2);
    variance_undo_persearch = pow((variance_undo_persearch /  RUNS), 0.5 );
    undo_SDOM = variance_undo_persearch /  pow(RUNS, 0.5);
#endif
    
    average_undo_persearch = total_undos / total_searches;
    printf("******************************************\n"); 
#ifdef CASE_1  
    printf("CASE_1 in known dynamic environments ! \n");
#endif          
    printf("Test Generaized - D*Lite (Sven's version) \n");
    printf("******************************************\n");   
    printf("KSWITCH == [%d] \n",   KSWITCH);
    printf("d star expansion  == %d \n",  expansionscount   );
    printf("d star searches_dstar / test case == %d \n",  searches_gdstar / RUNS);
    printf("d star expansion / search == [ %f ] \n", average_expansion_persearch);
    printf("d star SDOM of expansion / search == %f \n", SDOM); 
    printf("d star undo / search == [ %f ]\n", average_undo_persearch);
    printf("d star robot moved / test case == %d \n", robotmoves_total / RUNS);
    printf("d star total time ==  %f \n", time_gdstar);
    printf("total time/persearch == %f \n",   time_gdstar  / searches_gdstar   );
    printf("initia time/persearch == %f \n",   time_dstar_initialize / searches_gdstar    );
    printf("choose time/persearch == %f \n",   choose_target_togo0 / searches_gdstar    );
    printf("change_grid_time/persearch == %f \n",   change_grid_time / searches_gdstar    );
    printf("pure time without initi (include change)/persearch == %f \n",   (time_gdstar  - time_dstar_initialize - choose_target_togo0 )  / searches_gdstar   );
    printf("pure time without initi (exclude change)/persearch == %f \n",   (time_gdstar  - time_dstar_initialize - choose_target_togo0 - change_grid_time)  / searches_gdstar   );
    return;
}

#endif
