#ifndef MAZEH
#define MAZEH
#include "include.h"

struct cell;
typedef struct cell cell;

struct cell
{
    short obstacle;
    int x, y;
    int g, h, bfs_g;
    int heapindex;
    int generated;
    int iteration;
    int bfs_iteration;
    int expanded;
    int keymodifier;
    int path_iteration;
    int over_progagated;
    short child_number;
    short in_path;


    int cost[DIRECTIONS];   
    cell *move[DIRECTIONS];
    cell *succ[DIRECTIONS];
    cell *searchtree;
    cell *trace;
    cell *bfs_searchtree;
    cell *bfs_trace;
    cell *generate_next;
    cell *undo_next;

    int dfsx, dfsy; /* needed only for generating dfs mazes */

    int key[3];
    int rhs;
    int key1;
};



/////////////////////////////////////////////////////////////////////////////


cell *change_point_array[MAZEWIDTH * MAZEHEIGHT];
cell *unblockedcells[MAZEWIDTH * MAZEHEIGHT];
cell *blockedcells[MAZEWIDTH * MAZEHEIGHT];


int flag_changed;
int total_number_in_area ; 
int block_sum_number ; 
int unblock_sum_number ; 
int block_real_number ; 
int unblock_real_number ; 
int should_change_number; 
int half_change_number;  
int ch_number;

int   **mazeh;

cell **maze;
cell *mazegoal_old;
cell *mazestart_old;
cell *mazestart_last_search;


cell *target_new_destination;
cell *generate_anchor;
cell *undo_anchor;
cell *generate_end;
cell *undo_end;
cell *tmpcell1;
cell *mazegoal_all, *mazestart_all;
cell *mazestart, *mazegoal; 

int mazeiteration, searchiteration;
int RUN;


#endif
