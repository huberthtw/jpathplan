#include "stdio.h"
#include "include.h"
#include "heap.h"
#include "maze.h"
#include "astar.h"
#include "dstarlite.h"
#include "gdstar.h"
#include "math.h"

#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>







int main()
{
#ifdef UNKNOWN
    printf("Error! CASE_1 currently works with KNOWN environments ! \n");
    return;
#endif  

#ifdef TESTDIFFERENTIALASTAR
    #ifdef ADAPTIVE
        printf("Error! No Adaptive Differential A* yet ! \n");
            return;
    #endif
#endif  






#ifdef TESTASTAR
    call_astar();
#endif


#ifdef TESTDSTARLITE
    call_dstarlite();               // FRA* + D*Lite (Xiaoxun's version)
#endif


#ifdef TESTGDSTAR
    call_gdstar();                  // G-D* Lite (Sven's version)
#endif




    return 1;

}
