#ifndef HEAPH
#define HEAPH

#include "maze.h"

    #define HEAPSIZE 1000000

    cell *heap[HEAPSIZE];
    int heapsize;
    int keylength;
    void emptyheap(int length);
    int testheap();
    cell* popheap();
    cell *topheap();
    void deleteheap(cell *thiscell);
    void insertheap(cell *thiscell);
    void emptyheap2();
    cell * popheap2();
    cell *topheap2();
    void deleteheap2(cell *thiscell);
    void insertheap2(cell *thiscell);
    void insert_array_heap(cell *thiscell);
    void heapify (int i) ;
    void heapify_fringe() ;
#endif
