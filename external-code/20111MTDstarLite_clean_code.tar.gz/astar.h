#ifndef ASTARH
#define ASTARH



void initialize_state(cell *tmpcell);
void initialize_astar();
int computeshortestpath_astar();
void target_move();
void change_maze_traversability();
void consistent_procedure();
int test_astar();
void call_astar();
#endif
