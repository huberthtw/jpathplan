#ifndef GDSTARH
#define GDSTARH


void initializecell(cell *thiscell);
void updatecell(cell *thiscell);
void updatekey(cell *thiscell);
void updaterhs(cell *thiscell);
int computeshortestpath();
void updatemaze(cell *robot);
void targetmoved();
int robotstep();
int initialize_dstarlite_mts();
void call_dstarlite();


#endif
