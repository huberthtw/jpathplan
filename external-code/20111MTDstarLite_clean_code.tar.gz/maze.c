#include "include.h"
#include "maze.h"

cell **maze = NULL;
cell *mazestart, *mazegoal;
cell* mazegoal;
int mazeiteration = 0;
int searchiteration = 0;
short d;

int goaly = GOALY;
int goalx = GOALX;
int starty = STARTY;
int startx = STARTX;



void preprocessmaze()
{
    int x, y, d;
    int newx, newy;
    
    if (maze == NULL)
    {
        maze = (cell **)calloc(MAZEHEIGHT, sizeof(cell *));
        for (y = 0; y < MAZEHEIGHT; ++y)
            maze[y] = (cell *)calloc(MAZEWIDTH, sizeof(cell));
        
        // for for 1.
        for (y = 0; y < MAZEHEIGHT; ++y)
            for (x = 0; x < MAZEWIDTH; ++x)
            {
                maze[y][x].x = x;
                maze[y][x].y = y;
                for (d = 0; d < DIRECTIONS; ++d)
                {
                    newy = y + dy[d];
                    newx = x + dx[d];
                    maze[y][x].succ[d] = (newy >= 0 && newy < MAZEHEIGHT && newx >= 0 && newx < MAZEWIDTH) ? &maze[newy][newx] : NULL;
                    
                    maze[y][x].cost[d] = 1;
                }
            }
    } // end     if (maze == NULL)
    
    goaly = (random() % ((MAZEHEIGHT + 1) / 2)) * 2;
    goalx = (random() % ((MAZEWIDTH + 1) / 2)) * 2; 
    
    while (1)
    {
        starty = (random() % ((MAZEHEIGHT + 1) / 2)) * 2;
        startx = (random() % ((MAZEWIDTH + 1) / 2)) * 2;    
        
        if (startx != goalx || starty != goaly)
            break;
    }
    
#ifdef RANDOMMAZE
    //for for 2.
    for (y = 0; y < MAZEHEIGHT; ++y)
        for (x = 0; x < MAZEWIDTH; ++x)
        {
            maze[y][x].obstacle = (random() % 10000 < 10000 * MAZEDENSITY);
        }
#endif
        
        mazestart = &maze[starty][startx]; 
        mazegoal  = &maze[goaly][goalx];    
        
        maze[starty][startx].obstacle = 0;
        maze[goaly ][goalx ].obstacle = 0;
        mazeiteration = 0;
        searchiteration = 0;
}
//-------------------------------------------------------------------------------------------
void postprocessmaze()
{
    int x, y;
    short d1,d2;
    
    block_sum_number = 0;
    unblock_sum_number = 0;
    
    // for for 2.
    for (y = 0; y < MAZEHEIGHT; ++y)
        for (x = 0; x < MAZEWIDTH; ++x)
        {
            maze[y][x].generated = 0;
            maze[y][x].expanded = 0;
            maze[y][x].heapindex = 0;
            maze[y][x].iteration = 0;
            maze[y][x].path_iteration = 0;
            maze[y][x].in_path = 0;
            maze[y][x].bfs_iteration = 0;
            maze[y][x].over_progagated = 0;
            
            maze[y][x].searchtree = NULL;
            maze[y][x].trace = NULL;
            maze[y][x].bfs_searchtree = NULL;
            maze[y][x].bfs_trace = NULL;
            
            for (d1 = 0; d1 < DIRECTIONS; ++d1)
            {
#ifdef UNKNOWN
                maze[y][x].move[d1] = maze[y][x].succ[d1];
#else
                maze[y][x].move[d1] = (!maze[y][x].obstacle && maze[y][x].succ[d1] && !maze[y][x].succ[d1]->obstacle) ? maze[y][x].succ[d1] : NULL;
#endif
            }
            
#ifndef UNKNOWN
            if (maze[y][x].obstacle == 1) 
                blockedcells[block_sum_number++] = &maze[y][x];
            else
                unblockedcells[unblock_sum_number++] = &maze[y][x];             
#endif  
        }// end for for 2.
        
#ifndef UNKNOWN
        half_change_number = KSWITCH; 
        if (half_change_number > block_sum_number)  // because the number of blocks is less then unblock cells (25% vs 75%) 
            half_change_number = block_sum_number;  // we should test whether there are enough blocks to be unblocked.          
        if (half_change_number > unblock_sum_number)                                         
            half_change_number = unblock_sum_number; 
        ch_number = half_change_number * 2;
#endif
        
        
        
        
        
#ifdef UNKNOWN   // for MTS, D* Lite search from robot (=mazestart) to target (=mazegoal), so update the information for the robot 
        for (d1 = 0; d1 < DIRECTIONS; ++d1)
        {
            if (mazestart->move[d1] && mazestart->move[d1]->obstacle)
            {
                tmpcell1 = mazestart->move[d1];
                for (d2 = 0; d2 < DIRECTIONS; ++d2)
                {   
                    if (tmpcell1->move[d2])
                    {
                        tmpcell1->move[d2] = NULL;
                        tmpcell1->succ[d2]->move[reverse[d2]] = NULL;
                    }
                }
            }
        }
#endif
}
//------------------------------------------------------------------------------------
void newrandommaze()
{
    int x, y;
    
    preprocessmaze(); // 1____
    postprocessmaze();  // 2_____
}
//--------------------------------------------------------------------------------------------

void newdfsmaze(int wallstoremove)
{
    int d, dtmp;
    int x, y;
    int newx, newy;
    int randomnumber;
    int permute[8] = {0, 1, 2, 3, 4, 5, 6, 7};
    int permutetmp;
    
    preprocessmaze();   // pre --
    
    for (y = 0; y < MAZEHEIGHT; ++y)
        for (x = 0; x < MAZEWIDTH; ++x)
        {
            maze[y][x].obstacle = 1;
            maze[y][x].dfsx = 0;
            maze[y][x].dfsy = 0;
        }
        x = 0;
        y = 0;
        maze[y][x].dfsx = -1;
        maze[y][x].dfsy = -1;
        while (1)
        {
            if (maze[y][x].obstacle)
                maze[y][x].obstacle = 0;
            for (d = 0; d < DIRECTIONS-1; ++d)
            {
                randomnumber = random() % (DIRECTIONS-d);
                permutetmp = permute[randomnumber];
                permute[randomnumber] = permute[DIRECTIONS-1-d];
                permute[DIRECTIONS-1-d] = permutetmp;
            }
            for (dtmp = 0; dtmp < DIRECTIONS; ++dtmp)
            {
                d = permute[dtmp];
                newx = (x + 2*dx[d] + MAZEWIDTH) % MAZEWIDTH;
                newy = (y + 2*dy[d] + MAZEHEIGHT) % MAZEHEIGHT;
                if (maze[y][x].succ[d] != NULL && maze[newy][newx].obstacle)
                {
                    if (maze[(y + dy[d] + MAZEWIDTH) % MAZEWIDTH][(x + dx[d] + MAZEHEIGHT) % MAZEHEIGHT].obstacle)
                        maze[(y + dy[d] + MAZEWIDTH) % MAZEWIDTH][(x + dx[d] + MAZEHEIGHT) % MAZEHEIGHT].obstacle = 0;
                    maze[newy][newx].dfsx = x;
                    maze[newy][newx].dfsy = y;
                    x = newx;
                    y = newy;
                    break;
                }
            }
            if (dtmp == DIRECTIONS)
            {
                if (maze[y][x].dfsx == -1)
                    break;
                newx = maze[y][x].dfsx;
                newy = maze[y][x].dfsy;
                x = newx;
                y = newy;
            }
        }
        while (wallstoremove)
        {
            newx = random() % MAZEWIDTH;
            newy = random() % MAZEHEIGHT;
            if (maze[newy][newx].obstacle)
            {
                maze[newy][newx].obstacle = 0;
                --wallstoremove;
            }
        }
        postprocessmaze();
}























//--------------------------------------------------------------------------------------------------


void choose_maze_traversability()
{   
    long int i;
    int x,y;
    int random_number;
    int real_change_number;
    cell *tmpcell;
    
    
    real_change_number = 0; 
    
    // 1 --> 0 
    for(i = 0; i < half_change_number; i++) 
    { 
        random_number = random() % block_sum_number ;  //(generate a random number between 0 ---- block_sum_number - 1 )            
        change_point_array[real_change_number++] = blockedcells[random_number];
        block_sum_number--; 
        blockedcells[random_number] = blockedcells[block_sum_number]; 
        if(block_sum_number == 0)
            break;   
    }   
    // 0 --> 1 
    for(i = half_change_number; i < 2* half_change_number; i++) 
    { 
        
        while(unblock_sum_number > 0)
        {                           
            random_number = random() % unblock_sum_number ;  //(generate a random number between 0 ---- unblock_sum_number - 1 )    
            if(unblockedcells[random_number]->in_path == 1) // make sure not to block the mazestart, mazegoal, and the path between them
            {
                unblock_sum_number--; 
                unblockedcells[random_number] = unblockedcells[unblock_sum_number]; 
                
            }
            else // if(unblockedcells[random_number]->in_path == 0), which means unblockedcells[random_number] is not on the path, so can be blocked
                break; // break while
        }
        if(unblock_sum_number == 0)
            break;  // break for(i)
        change_point_array[real_change_number++] = unblockedcells[random_number];
        unblock_sum_number--; 
        unblockedcells[random_number] = unblockedcells[unblock_sum_number]; 
    }   
    // 3. re-insert the cell to the pool
    for(i = 0; i < real_change_number; i++)
    {   
        tmpcell = change_point_array[i];  
        if(tmpcell->obstacle  == 1)
            unblockedcells[unblock_sum_number++] = tmpcell;
        else // if(tmpcell->obstacle  == 0)
            blockedcells[block_sum_number++] = tmpcell;
        
    }
    
    return;
}
